package com.shikarchi.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val requestCapture = 7101
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this).apply {
            textSize = 16f
            text = "آمادهٔ آزمایش تشخیص نماد از صفحهٔ گوشی"
            setPadding(0, 20, 0, 20)
        }

        val title = TextView(this).apply {
            text = "شکارچی — نمونهٔ اندرویدی ۰٫۱"
            textSize = 23f
            setPadding(0, 12, 0, 18)
        }
        val explanation = TextView(this).apply {
            textSize = 15f
            text = "این نمونه فقط با اجازهٔ شما از صفحه تصویر می‌گیرد و متن‌های قابل‌مشاهده را برای تشخیص نماد استخراج می‌کند. هنوز سیگنال معاملاتی تولید نمی‌کند و هیچ معامله‌ای اجرا نمی‌کند."
            setPadding(0, 0, 0, 18)
        }
        val start = Button(this).apply {
            text = "شروع اشتراک‌گذاری صفحه"
            setOnClickListener {
                val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
            }
        }
        val stop = Button(this).apply {
            text = "توقف دریافت صفحه"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "دریافت صفحه متوقف شد."
            }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            addView(title)
            addView(explanation)
            addView(start)
            addView(stop)
            addView(status)
        }
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    @Deprecated("Deprecated in Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            startForegroundService(serviceIntent)
            status.text = "اجازه دریافت شد؛ حالا می‌توانید به توبیت یا MT5 بروید. برای توقف، به شکارچی برگردید."
        } else if (requestCode == requestCapture) {
            status.text = "اجازهٔ اشتراک‌گذاری صفحه داده نشد."
        }
    }
}
